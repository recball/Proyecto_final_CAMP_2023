echo ligando C00091277
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00091277.pdbqt --config config.txt --log 4kd1FH/C00091277.log --out 4kd1FH/C00091277_out.pdbqt
echo ligando C00115235
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00115235.pdbqt --config config.txt --log 4kd1FH/C00115235.log --out 4kd1FH/C00115235_out.pdbqt
echo ligando C00166118
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00166118.pdbqt --config config.txt --log 4kd1FH/C00166118.log --out 4kd1FH/C00166118_out.pdbqt
echo ligando C00170064
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00170064.pdbqt --config config.txt --log 4kd1FH/C00170064.log --out 4kd1FH/C00170064_out.pdbqt
echo ligando C00187202
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00187202.pdbqt --config config.txt --log 4kd1FH/C00187202.log --out 4kd1FH/C00187202_out.pdbqt
echo ligando C00226517
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00226517.pdbqt --config config.txt --log 4kd1FH/C00226517.log --out 4kd1FH/C00226517_out.pdbqt
echo ligando C00226552
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00226552.pdbqt --config config.txt --log 4kd1FH/C00226552.log --out 4kd1FH/C00226552_out.pdbqt
echo ligando C00226694
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00226694.pdbqt --config config.txt --log 4kd1FH/C00226694.log --out 4kd1FH/C00226694_out.pdbqt
echo ligando C00247613
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00247613.pdbqt --config config.txt --log 4kd1FH/C00247613.log --out 4kd1FH/C00247613_out.pdbqt
echo ligando C00248407
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00248407.pdbqt --config config.txt --log 4kd1FH/C00248407.log --out 4kd1FH/C00248407_out.pdbqt
echo ligando C00248995
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00248995.pdbqt --config config.txt --log 4kd1FH/C00248995.log --out 4kd1FH/C00248995_out.pdbqt
echo ligando C00300600
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00300600.pdbqt --config config.txt --log 4kd1FH/C00300600.log --out 4kd1FH/C00300600_out.pdbqt
echo ligando C00300759
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00300759.pdbqt --config config.txt --log 4kd1FH/C00300759.log --out 4kd1FH/C00300759_out.pdbqt
echo ligando C00301073
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00301073.pdbqt --config config.txt --log 4kd1FH/C00301073.log --out 4kd1FH/C00301073_out.pdbqt
echo ligando C00301242
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00301242.pdbqt --config config.txt --log 4kd1FH/C00301242.log --out 4kd1FH/C00301242_out.pdbqt
echo ligando C00303681
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00303681.pdbqt --config config.txt --log 4kd1FH/C00303681.log --out 4kd1FH/C00303681_out.pdbqt
echo ligando C00303796
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00303796.pdbqt --config config.txt --log 4kd1FH/C00303796.log --out 4kd1FH/C00303796_out.pdbqt
echo ligando C00310679
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00310679.pdbqt --config config.txt --log 4kd1FH/C00310679.log --out 4kd1FH/C00310679_out.pdbqt
echo ligando C00310895
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00310895.pdbqt --config config.txt --log 4kd1FH/C00310895.log --out 4kd1FH/C00310895_out.pdbqt
echo ligando C00311564
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00311564.pdbqt --config config.txt --log 4kd1FH/C00311564.log --out 4kd1FH/C00311564_out.pdbqt
echo ligando C00311617
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00311617.pdbqt --config config.txt --log 4kd1FH/C00311617.log --out 4kd1FH/C00311617_out.pdbqt
echo ligando C00312614
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00312614.pdbqt --config config.txt --log 4kd1FH/C00312614.log --out 4kd1FH/C00312614_out.pdbqt
echo ligando C00316291
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00316291.pdbqt --config config.txt --log 4kd1FH/C00316291.log --out 4kd1FH/C00316291_out.pdbqt
echo ligando C00319947
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00319947.pdbqt --config config.txt --log 4kd1FH/C00319947.log --out 4kd1FH/C00319947_out.pdbqt
echo ligando C00320729
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00320729.pdbqt --config config.txt --log 4kd1FH/C00320729.log --out 4kd1FH/C00320729_out.pdbqt
echo ligando C00324526
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00324526.pdbqt --config config.txt --log 4kd1FH/C00324526.log --out 4kd1FH/C00324526_out.pdbqt
echo ligando C00339679
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00339679.pdbqt --config config.txt --log 4kd1FH/C00339679.log --out 4kd1FH/C00339679_out.pdbqt
echo ligando C00341636
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00341636.pdbqt --config config.txt --log 4kd1FH/C00341636.log --out 4kd1FH/C00341636_out.pdbqt
echo ligando C00350676
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00350676.pdbqt --config config.txt --log 4kd1FH/C00350676.log --out 4kd1FH/C00350676_out.pdbqt
echo ligando C00361236
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00361236.pdbqt --config config.txt --log 4kd1FH/C00361236.log --out 4kd1FH/C00361236_out.pdbqt
echo ligando C00410894
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00410894.pdbqt --config config.txt --log 4kd1FH/C00410894.log --out 4kd1FH/C00410894_out.pdbqt
echo ligando C00410904
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00410904.pdbqt --config config.txt --log 4kd1FH/C00410904.log --out 4kd1FH/C00410904_out.pdbqt
echo ligando C00429512
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00429512.pdbqt --config config.txt --log 4kd1FH/C00429512.log --out 4kd1FH/C00429512_out.pdbqt
echo ligando C00440715
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00440715.pdbqt --config config.txt --log 4kd1FH/C00440715.log --out 4kd1FH/C00440715_out.pdbqt
echo ligando C00440719
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00440719.pdbqt --config config.txt --log 4kd1FH/C00440719.log --out 4kd1FH/C00440719_out.pdbqt
echo ligando C00452367
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00452367.pdbqt --config config.txt --log 4kd1FH/C00452367.log --out 4kd1FH/C00452367_out.pdbqt
echo ligando C00453116
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00453116.pdbqt --config config.txt --log 4kd1FH/C00453116.log --out 4kd1FH/C00453116_out.pdbqt
echo ligando C00494698
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00494698.pdbqt --config config.txt --log 4kd1FH/C00494698.log --out 4kd1FH/C00494698_out.pdbqt
echo ligando C00512154
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00512154.pdbqt --config config.txt --log 4kd1FH/C00512154.log --out 4kd1FH/C00512154_out.pdbqt
echo ligando C00512304
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00512304.pdbqt --config config.txt --log 4kd1FH/C00512304.log --out 4kd1FH/C00512304_out.pdbqt
echo ligando C00512306
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00512306.pdbqt --config config.txt --log 4kd1FH/C00512306.log --out 4kd1FH/C00512306_out.pdbqt
echo ligando C00554577
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00554577.pdbqt --config config.txt --log 4kd1FH/C00554577.log --out 4kd1FH/C00554577_out.pdbqt
echo ligando C00556304
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00556304.pdbqt --config config.txt --log 4kd1FH/C00556304.log --out 4kd1FH/C00556304_out.pdbqt
echo ligando C00559773
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00559773.pdbqt --config config.txt --log 4kd1FH/C00559773.log --out 4kd1FH/C00559773_out.pdbqt
echo ligando C00574915
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00574915.pdbqt --config config.txt --log 4kd1FH/C00574915.log --out 4kd1FH/C00574915_out.pdbqt
echo ligando C00575087
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00575087.pdbqt --config config.txt --log 4kd1FH/C00575087.log --out 4kd1FH/C00575087_out.pdbqt
echo ligando C00613038
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/C00613038.pdbqt --config config.txt --log 4kd1FH/C00613038.log --out 4kd1FH/C00613038_out.pdbqt
echo ligando lista_activo
./smina.static --receptor receptor/4kd1FH.pdbqt --ligand ligandos/lista_activo.pdbqt --config config.txt --log 4kd1FH/lista_activo.log --out 4kd1FH/lista_activo_out.pdbqt
