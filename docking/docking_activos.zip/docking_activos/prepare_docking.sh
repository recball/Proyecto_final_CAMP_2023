#!/usr/bin/env bash
#Uso: bash prepare_docking.sh carpeta_ligandos carpeta_receptores ejecutable_vina config

usage="USO: bash $(basename "$0") carpeta_ligandos carpeta_receptores ejecutable_vina archivo_config"

if [ ${#@} != 4 ]; then  
	echo $usage
	exit
fi

carpeta_ligandos=$1
carpeta_receptores=$2
archivo_vina=$3
archivo_config=$4

> run_todo.sh

for receptor in $( ls $carpeta_receptores | grep pdbqt | cut -f1 -d "." ); do
	mkdir $receptor
	receptor_file=run\_$receptor\_$( basename $archivo_vina | cut -f1 -d "." )\.sh
	> run\_$receptor\_$( basename $archivo_vina | cut -f1 -d "." )\.sh
	for lig in $( ls $carpeta_ligandos | grep pdbqt | cut -f1 -d "." ); do
		echo echo ligando $lig >> $receptor_file
		echo $archivo_vina --receptor $carpeta_receptores/$receptor\.pdbqt --ligand $carpeta_ligandos/$lig\.pdbqt --config $archivo_config --log $receptor/$lig\.log --out $receptor/$lig\_out.pdbqt >> $receptor_file
	done
	echo sh $receptor_file >> run_todo.sh
done


