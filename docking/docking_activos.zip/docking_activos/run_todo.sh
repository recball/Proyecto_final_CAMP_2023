sh run_4kd1FH_smina.sh
